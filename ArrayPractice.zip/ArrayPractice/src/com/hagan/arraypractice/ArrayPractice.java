/**
 * @author Shane Hagan
 * Project: Array Practice Assignment TEKJava
 */

package com.hagan.arraypractice;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayPractice {

	public static void main(String[] args) {
		Problem1();
		Problem2();
		Problem3();
		Problem4();
		Problem5();
		Problem6();
		Problem7();
		Problem8();
		Problem9();
		Problem10();
		determineFavoriteThings();
		}
	
	public static void Problem1() {
		int[] arr = {1, 2, 3};
		
		System.out.println("Bullet Point 1 Solution: ");
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
	
	public static void Problem2() {
		int[] arr = {13, 5, 7, 68, 2};
		
		System.out.println("Bullet Point 2 Solution: " + arr[2]);
	}
	
	public static void Problem3() {
		String[] arr = {"red", "green", "blue", "yellow"};
		
		System.out.println("Bullet Point 3 Solution: ");
		System.out.println(arr.length);
		
		String[] arr2 = arr.clone();
		System.out.println(Arrays.toString(arr2));
	}

	public static void Problem4() {
		int[] arr = {1, 2, 3, 4, 5};
		
		System.out.println("Bullet Point 4 Solution: ");
		System.out.println(arr[0]);
		System.out.println(arr[arr.length - 1]);
		
		/**
		 * Index out of bounds error for the below 
		 */
		//System.out.println(arr[arr.length]);
		//arr[5] = 6;
	}
	
	public static void Problem5() {
		int[] arr = new int[5];
		
		System.out.println("Bullet Point 5 Solution: ");
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = i;
			System.out.println(arr[i]);
		}
	}
	
	public static void Problem6() {
		int[] arr = new int[5];
		
		System.out.println("Bullet Point 6 Solution: ");
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = i * 2;
			System.out.println(arr[i]);
		}
	}
	
	public static void Problem7() {
		System.out.println("Bullet Point 7 Solution: ");
		int[] arr = new int[5];
		arr[0] = 1;
		arr[1] = 10;
		arr[2] = 100;
		arr[3] = 1000;
		arr[4] = 10000;
		
		for (int i = 0; i < arr.length; i++) {
			if (i != 2) {
				System.out.println(arr[i]);
			}
			else {
			}
		}
	}
	
	public static void Problem8() {
		String[] arr = {"one", "two", "three", "four", "five"};
		
		System.out.println("Bullet Point 8 Solution: ");
		System.out.println("Before: " + Arrays.toString(arr));
		
		String tempString = arr[2];
		arr[2] = arr[0];
		arr[0] = tempString;
		
		System.out.println("After: " + Arrays.toString(arr));
		
	}
	
	public static void Problem9() {
		int[] arr = {4, 2, 9, 13, 1, 0};
		
		Arrays.sort(arr);
		
		System.out.println("Bullet Point 9 Solution: ");
		
		System.out.println("Array in ascending order: " + Arrays.toString(arr));
		
		int minVal = Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < minVal) {
				minVal = arr[i];
			}
		}
		System.out.println("The smallest number is " + minVal);
		
		
		int maxVal = Integer.MIN_VALUE;
		for(int i=0; i < arr.length; i++){
			if(arr[i] > maxVal){
					maxVal = arr[i];
			}
		}
		System.out.println("The biggest number is " + maxVal);
	}
	
	public static void Problem10() {
		Object[] arr = new Object[5];
		arr[0] = 1;
		arr[1] = "Hello";
		arr[2] = "World";
		arr[3] = "!";
		arr[4] = 4.00001d;
		
		System.out.println("Bullet Point 9 Solution: ");
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		
	}
	
	public static void determineFavoriteThings() {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Bullet Point 11 / Favorite Thing Solution: ");
		
		System.out.println("How many favorite things do you have?");
		int favoriteCount = input.nextInt();
		input.nextLine();
		
		String[] favoriteList = new String[favoriteCount];
		
		for (int i = 0; i < favoriteCount; i++) {
			System.out.print("Enter your thing: ");
			favoriteList[i] = input.nextLine();
		}
		
		input.close();
		System.out.println("Your favorite things are: ");
		
		for (int i = 0;  i < favoriteList.length; i++) {
			System.out.print(favoriteList[i] + " ");
		}
		
	}
}
