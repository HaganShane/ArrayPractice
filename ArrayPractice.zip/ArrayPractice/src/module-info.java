module ArrayPractice {
}